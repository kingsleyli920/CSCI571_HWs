package com.usc.kunchenl.pagessearch.myAdapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.usc.kunchenl.pagessearch.fragments.FavoriteFragment;
import com.usc.kunchenl.pagessearch.fragments.SearchFragment;

import java.util.ArrayList;
import java.util.List;

public class MyMainFragmentsAdapter extends FragmentPagerAdapter {
    private String[] mTitles = new String[]{"SEARCH", "FAVORITES"};

    public MyMainFragmentsAdapter(FragmentManager fm) {
        super(fm);
    }
    @Override
    public Fragment getItem(int position) {

        if (position == 0)
            return new SearchFragment();
        return new FavoriteFragment();
    }

    @Override
    public int getCount() {
        return mTitles.length;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTitles[position];
    }
}
