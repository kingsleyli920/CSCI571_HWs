package com.usc.kunchenl.pagessearch.myAdapter;

import android.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ExecuteNearbyResponse;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.SaveToLocalStorageUtility;
import com.usc.kunchenl.pagessearch.fragments.FavoriteFragment;
import com.usc.kunchenl.pagessearch.interfaces.OnItemClickListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MyFavoritesAdapter extends RecyclerView.Adapter<MyFavoritesAdapter.MyViewHolder> {

    private AppCompatActivity activity;
    private Map<String, ?> localData;
    private ImageView icon;
    private TextView name;
    private TextView vicinity;
    private List<Map<String, String>> mapList;
    private ImageView favorite_img;
    private SaveToLocalStorageUtility saveToLocalStorageUtility;
    private TextView textView;
    private OnItemClickListener mOnItemClickListener;
    private NearbyResultItemUtility nearbyResultItemUtility;

    public MyFavoritesAdapter(AppCompatActivity searchActivity, Map<String, ?> localData, OnItemClickListener mOnItemClickListener) {
        this.activity = searchActivity;
        this.localData = localData;
        this.mOnItemClickListener = mOnItemClickListener;
        textView = activity.findViewById(R.id.no_favorites);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(activity).inflate(R.layout.result_item, parent, false);
        mapList = new ArrayList<Map<String, String>>();
        favorite_img = (ImageView) view.findViewById(R.id.favorite_btn);
        MyViewHolder holder = new MyViewHolder(view, favorite_img);
        return holder;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        mapList = extractData();
        holder.bind(position, mOnItemClickListener);
        holder.imageView.setBackgroundResource(R.drawable.heart_fill_red);

    }

    @Override
    public int getItemCount() {
        return localData.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private ImageView imageView;

        public MyViewHolder(View view, ImageView imageView) {

            super(view);
            this.imageView = imageView;
            icon = (ImageView) view.findViewById(R.id.icon);
            name = (TextView) view.findViewById(R.id.name);
            vicinity = (TextView) view.findViewById(R.id.vicinity);
            imageView.setOnClickListener(this);
        }

        // favorite_btn onclick
        @Override
        public void onClick(View v) {
            saveToLocalStorageUtility = new SaveToLocalStorageUtility(activity);
            String place_id = mapList.get(getAdapterPosition()).get("place_id");
            String name = mapList.get(getAdapterPosition()).get("name");
            String vicinity = mapList.get(getAdapterPosition()).get("vicinity");
            if (saveToLocalStorageUtility.checkExist(place_id)) {
                saveToLocalStorageUtility.removeFromStorage(place_id);
            }
            String removeText = name + " at " + vicinity + " has been removed from favorite list";

            if (!saveToLocalStorageUtility.checkExist(place_id)) {
                Toast.makeText(activity, removeText, Toast.LENGTH_SHORT).show();
                imageView.setBackgroundResource(R.drawable.heart_outline_black);
                removeItem(getAdapterPosition(), place_id);
            }

            if (localData.size() == 0) {
                textView.setVisibility(View.VISIBLE);
            }
        }

        public void bind(final int position, final OnItemClickListener listener) {
            name.setText(mapList.get(position).get("name"));
            Glide.with(activity).load(mapList.get(position).get("icon")).into(icon);
            vicinity.setText(mapList.get(position).get("vicinity"));
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    nearbyResultItemUtility = new NearbyResultItemUtility();
                    nearbyResultItemUtility.setPlaceId(mapList.get(position).get("place_id"));
                    nearbyResultItemUtility.setName(mapList.get(position).get("name"));
                    nearbyResultItemUtility.setRating(mapList.get(position).get("rating"));
                    nearbyResultItemUtility.setPrice_level(mapList.get(position).get("price_level"));
                    nearbyResultItemUtility.setLat(mapList.get(position).get("lat"));
                    nearbyResultItemUtility.setLng(mapList.get(position).get("lng"));
                    nearbyResultItemUtility.setIcon(mapList.get(position).get("icon"));
                    nearbyResultItemUtility.setVicinity(mapList.get(position).get("vicinity"));
                    listener.onItemClick(nearbyResultItemUtility);
                }
            });
        }
    }

    private List<Map<String, String>> extractData() {
        Map<String, String> map;
        List<Map<String, String>> mapList;
        mapList = new ArrayList<Map<String, String>>();
        for (Map.Entry<String, ?> entry : localData.entrySet()) {
            String value = String.valueOf(entry.getValue());
            map = new ExecuteNearbyResponse().getLocalData(value);
            mapList.add(map);
        }
        Collections.reverse(mapList);

        return mapList;
    }

    private void removeItem(int position, String place_id) {

        localData.remove(place_id.replace("\"", ""));
        mapList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, getItemCount() - position);
//        notifyDataSetChanged();


    }
}