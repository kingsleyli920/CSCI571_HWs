package com.usc.kunchenl.pagessearch.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.FileProvider;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.places.GeoDataClient;
import com.google.android.gms.location.places.PlacePhotoMetadata;
import com.google.android.gms.location.places.PlacePhotoMetadataBuffer;
import com.google.android.gms.location.places.PlacePhotoMetadataResponse;
import com.google.android.gms.location.places.PlacePhotoResponse;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterConfig;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.tweetcomposer.ComposerActivity;
import com.twitter.sdk.android.tweetcomposer.TweetComposer;
import com.usc.kunchenl.pagessearch.BuildConfig;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.SaveToLocalStorageUtility;
import com.usc.kunchenl.pagessearch.Utilities.URLRequestUtility;
import com.usc.kunchenl.pagessearch.fragments.InfoFragment;
import com.usc.kunchenl.pagessearch.myAdapter.MyMainFragmentsAdapter;
import com.usc.kunchenl.pagessearch.myAdapter.MyPhotosAdapter;
import com.usc.kunchenl.pagessearch.myAdapter.MyPlaceDetailFragmentsAdapter;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlaceDetailsActivity extends AppCompatActivity {

    private Toolbar mToolbar;

    private ViewPager mViewPager;
    private TabLayout mTabLayout;
    private String pageTitle;
    private List<String> localData;

    private MyPlaceDetailFragmentsAdapter myPlaceDetailFragmentsAdapter;

    private TabLayout.Tab info;
    private TabLayout.Tab photo;
    private TabLayout.Tab map;
    private TabLayout.Tab reviews;
    private ArrayList<Bitmap> bitmapList;
    private GeoDataClient mGeoDataClient;
    private NearbyResultItemUtility item;
    private SaveToLocalStorageUtility saveToLocalStorageUtility;
    private MenuItem favorite_btn;
    private Menu menu;
    private String place_id;
    private String JsonData;
    private String responseData;
    private Map<String, String> addressMap;
    private URLRequestUtility urlRequestUtility;
    private static final String BEST_MATCH_YELP_PLACE = "http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/yelp/best_match?";
//    private static final String GET_REVIEWS = "http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/yelp/reviews?id=";
    private static final String TWITTER_CUSTOMER_KEY = "WkQLZOe6wluJnMUg9uRrt1B0C";
    private static final String TWITTER_CUSTOMER_SECURITY = "xuVekAnCjX7WIcFNuXfixg9tgLibIYdxPxEGYibFxEHcwjM2nI";
    private String yelp_place_id;
    private String twitterText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.place_details_main);

        // Initialize Twitter
        TwitterConfig config = new TwitterConfig.Builder(this)
                .logger(new DefaultLogger(Log.DEBUG))
                .twitterAuthConfig(new TwitterAuthConfig(TWITTER_CUSTOMER_KEY, TWITTER_CUSTOMER_SECURITY))
                .debug(true)
                .build();
        Twitter.initialize(config);
        Bundle bundle = this.getIntent().getExtras();
        if (bundle != null) {

            item = getData();
            twitterText = "check out " + item.getName()
                    + " at " + item.getFormatted_address().substring(1, item.getFormatted_address().length()-1)
                    + " which url is : " + item.getUrl().substring(1) + ".";
            JsonData = bundle.getString("jsonData", null);

        }
        mToolbar = (Toolbar) findViewById(R.id.toolbar_details);
        initToolbar();
        // Construct a GeoDataClient.
        mGeoDataClient = Places.getGeoDataClient(this, null);
        bitmapList = new ArrayList<>();
        saveToLocalStorageUtility = new SaveToLocalStorageUtility(this);
        localData = new ArrayList<String>();

        place_id = item.getPlaceId();
        getPhotos(place_id);
        requestYelpPlaceId(getAddressParams());
        System.out.println(item.getVicinity());

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        this.menu = menu;
        favorite_btn = menu.getItem(1);

        if (isSavedItem()) {
            favorite_btn.setIcon(getResources().getDrawable(R.drawable.heart_fill_red));
        } else {
            favorite_btn.setIcon(getResources().getDrawable(R.drawable.heart_fill_white));
        }
        return super.onCreateOptionsMenu(menu);
    }

    private void initToolbar() {

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            pageTitle = bundle.getString("page_title");
        }
        mToolbar.setTitle(pageTitle);

        if (mToolbar != null) {
            setSupportActionBar(mToolbar);//To display toolbar
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setElevation(0);
        }

        // Set menu item onclick listener
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                String saveText = item.getName() + " at "
                        + item.getVicinity()
                        + "has been added to favorite list";

                String removeText = item.getName() + " at "
                        + item.getVicinity()
                        + "has been removed from favorite list";
                int menuItemId = menuItem.getItemId();
                if (menuItemId == R.id.share) {

//                    Toast.makeText(PlaceDetailsActivity.this, R.string.share, Toast.LENGTH_SHORT).show();
                    TweetComposer.Builder builder = new TweetComposer.Builder(PlaceDetailsActivity.this)
                            .text(twitterText);
                    builder.show();
                } else if (menuItemId == R.id.favorites) {
                    if (isSavedItem()) {
                        saveToLocalStorageUtility.removeFromStorage(place_id);
                        if (!saveToLocalStorageUtility.checkExist(place_id)) {
                            Toast.makeText(PlaceDetailsActivity.this, removeText, Toast.LENGTH_SHORT).show();
                            favorite_btn.setIcon(getResources().getDrawable(R.drawable.heart_fill_white));
                        } else {
                            Toast.makeText(PlaceDetailsActivity.this, "Failed to remove item from favorites list, please try again", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        saveToLocalStorageUtility.putInStorage(place_id, JsonData);
                        //System.out.println(saveToLocalStorageUtility.getAll().size());
                        if (isSavedItem()) {
                            Toast.makeText(PlaceDetailsActivity.this, saveText, Toast.LENGTH_SHORT).show();
                            favorite_btn.setIcon(getResources().getDrawable(R.drawable.heart_fill_red));
                        } else {
                            Toast.makeText(PlaceDetailsActivity.this, "Failed to add item to favorites list, please try again", Toast.LENGTH_SHORT).show();
                        }

                    }


                }
                return true;
            }
        });

        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        initTabbar();
    }

    // Initialize views
    private void initTabbar() {

        mViewPager = (ViewPager) findViewById(R.id.container);
        myPlaceDetailFragmentsAdapter = new MyPlaceDetailFragmentsAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(myPlaceDetailFragmentsAdapter);
        mTabLayout = (TabLayout) findViewById(R.id.tabs);
        mTabLayout.setupWithViewPager(mViewPager);

        // Draw separator line between tabs
        View root = mTabLayout.getChildAt(0);
        if (root instanceof LinearLayout) {
            ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(getResources().getColor(R.color.separator));
            drawable.setSize(2, 1);
            ((LinearLayout) root).setDividerPadding(10);
            ((LinearLayout) root).setDividerDrawable(drawable);
        }

        // Set custom view for tabbars
        TextView infoNewTab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        infoNewTab.setText(R.string.info);
        infoNewTab.setCompoundDrawablesWithIntrinsicBounds(R.drawable.info_outline, 0, 0, 0);
        info = mTabLayout.getTabAt(0).setCustomView(infoNewTab);

        TextView photosNewTab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        photosNewTab.setText(R.string.photos);
        photosNewTab.setCompoundDrawablesWithIntrinsicBounds(R.drawable.photos, 0, 0, 0);
        photo = mTabLayout.getTabAt(1).setCustomView(photosNewTab);

        TextView mapNewTab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        mapNewTab.setText(R.string.map);
        mapNewTab.setCompoundDrawablesWithIntrinsicBounds(R.drawable.maps, 0, 0, 0);
        map = mTabLayout.getTabAt(2).setCustomView(mapNewTab);

        TextView reviewsNewTab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        reviewsNewTab.setText(R.string.reviews);
        reviewsNewTab.setCompoundDrawablesWithIntrinsicBounds(R.drawable.review, 0, 0, 0);
        reviews = mTabLayout.getTabAt(3).setCustomView(reviewsNewTab);

    }

    // Get place photos

    private void getPhotos(String id) {
//        final String placeId = "ChIJa147K9HX3IAR-lwiGIQv9i4";
        final Task<PlacePhotoMetadataResponse> photoMetadataResponse = mGeoDataClient.getPlacePhotos(id);
        photoMetadataResponse.addOnCompleteListener(new OnCompleteListener<PlacePhotoMetadataResponse>() {
            @Override
            public void onComplete(@NonNull Task<PlacePhotoMetadataResponse> task) {
                // Get the list of photos.
                PlacePhotoMetadataResponse photos = task.getResult();
                // Get the PlacePhotoMetadataBuffer (metadata for all of the photos).
                PlacePhotoMetadataBuffer photoMetadataBuffer = photos.getPhotoMetadata();
                for (PlacePhotoMetadata photoMetadata : photoMetadataBuffer) {
                    // Get a full-size bitmap for the photo.
                    Task<PlacePhotoResponse> photoResponse = mGeoDataClient.getPhoto(photoMetadata);
                    photoResponse.addOnCompleteListener(new OnCompleteListener<PlacePhotoResponse>() {
                        @Override
                        public void onComplete(@NonNull Task<PlacePhotoResponse> task) {
                            PlacePhotoResponse photo = task.getResult();
                            Bitmap bitmap = photo.getBitmap();
                            bitmapList.add(bitmap);
                        }
                    });
                }
            }
        });
    }

    public ArrayList<Bitmap> getBitmapList() {
        return bitmapList;
    }

    private boolean isSavedItem() {
        Map<String, ?> map = saveToLocalStorageUtility.getAll();
        for (Map.Entry<String, ?> entry : map.entrySet()) {
            System.out.println("key: " + entry.getKey() + " value: " + entry.getValue());
            if (entry.getKey().equals(place_id)) {

                return true;
            }

        }
        return false;
    }

    private Map<String, String> getAddressParams() {
        Bundle bundle = getIntent().getExtras();
        addressMap = new HashMap<>();
        String item_str = bundle.getString("item", null);
        item = new Gson().fromJson(item_str, NearbyResultItemUtility.class);
        String name = item.getName();
        if (bundle != null) {
            String responseData = bundle.getString("jsonResponse");
            JsonObject mDataJson = new ConvertToJsonObj(responseData).convertToJson();
            JsonObject resultJson = mDataJson.getAsJsonObject("result");

            String formatted_address = "";
            if (resultJson.has("formatted_address")) {
                formatted_address = resultJson.get("formatted_address").toString().replace("\"", "");
            }
            String county = null;
            String state = null;
            String country = null;
            if (resultJson.has("address_components")) {
                JsonArray jsonArray = resultJson.getAsJsonArray("address_components");
                for (JsonElement jsonElement : jsonArray) {
                    JsonObject eleobj = (JsonObject) jsonElement;
                    JsonArray typesArr = eleobj.getAsJsonArray("types");
                    for (JsonElement type : typesArr) {
                        String typeStr = type.getAsString().replace("\"", "");
                        if (typeStr.equals("administrative_area_level_2")) {
                            county = String.valueOf(eleobj.get("short_name")).replace("\"", "");

                        }
                        if (typeStr.equals("administrative_area_level_1")) {
                            state = String.valueOf(eleobj.get("short_name")).replace("\"", "");
                        }
                        if (typeStr.equals("country")) {
                            country = String.valueOf(eleobj.get("short_name")).replace("\"", "");
                        }
                    }
                }
            }
            addressMap.put("county", county);
            addressMap.put("state", state);
            addressMap.put("country", country);
            addressMap.put("name", name);
            addressMap.put("formatted_address", formatted_address);
            return addressMap;
        }
        return null;

    }

    private void requestYelpPlaceId(Map<String, String> paramsMap) {
        String county = paramsMap.get("county");
        String state = paramsMap.get("state");
        String country = paramsMap.get("country");
        String name = paramsMap.get("name");
        String formatted_address = paramsMap.get("formatted_address");
        String params = "city=" + county + "&state=" + state + "&country=" + country + "&name=" + name +
                "&addr1=" + formatted_address;
        String URL = BEST_MATCH_YELP_PLACE + params;
        System.out.println(URL);
        urlRequestUtility = new URLRequestUtility();
        try {
            urlRequestUtility.startConnection(URL
                    , new URLRequestUtility.NetworkResponse() {
                        @Override
                        public void onSuccess(final String body) {
                            final String response = body;

                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    yelp_place_id = response;
//                                    String reviews_url = GET_REVIEWS + yelp_place_id;
//                                    System.out.print(reviews_url);
                                }
                            });

                        }

                        @Override
                        public void onFailure() {
                            System.out.println("failed");
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("finish");
    }

    public String getYelpPlaceId() {
        return yelp_place_id;
    }


    // get delivered data and responsed data from url
    public NearbyResultItemUtility getData() {
        Bundle bundle = getIntent().getExtras();
        NearbyResultItemUtility nearbyResultItemUtility = null;

        if (bundle != null) {
            responseData = bundle.getString("jsonResponse");
            System.out.println("Details response: " + responseData);
            String item_str = bundle.getString("item", null);
            nearbyResultItemUtility = new Gson().fromJson(item_str, NearbyResultItemUtility.class);
            JsonObject mDataJson = new ConvertToJsonObj(responseData).convertToJson();
            JsonObject resultJson = mDataJson.getAsJsonObject("result");

            String formatted_address = "";
            String formatted_phone_number = "";
            String url = "";
            String website = "";

            if (resultJson.has("formatted_address")) {
                formatted_address = resultJson.get("formatted_address").toString();
            }

            if (resultJson.has("formatted_phone_number")) {
                formatted_phone_number = resultJson.get("formatted_phone_number").toString();
            }

            if (resultJson.has("url")) {
                url = resultJson.get("url").toString();
            }

            if (resultJson.has("website")) {
                website = resultJson.get("website").toString();
            }

            if (nearbyResultItemUtility != null) {
                nearbyResultItemUtility.setFormatted_address(formatted_address);
                nearbyResultItemUtility.setFormatted_phone_number(formatted_phone_number);
                nearbyResultItemUtility.setUrl(url);
                nearbyResultItemUtility.setWebsite(website);
            }
            
            

        }
        return nearbyResultItemUtility;

    }
}
