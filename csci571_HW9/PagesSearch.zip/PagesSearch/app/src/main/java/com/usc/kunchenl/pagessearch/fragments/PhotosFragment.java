package com.usc.kunchenl.pagessearch.fragments;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.location.places.GeoDataClient;
import com.google.android.gms.location.places.PlacePhotoMetadata;
import com.google.android.gms.location.places.PlacePhotoMetadataBuffer;
import com.google.android.gms.location.places.PlacePhotoMetadataResponse;
import com.google.android.gms.location.places.PlacePhotoResponse;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.activities.PlaceDetailsActivity;
import com.usc.kunchenl.pagessearch.myAdapter.MyPhotosAdapter;
import com.usc.kunchenl.pagessearch.myAdapter.MyResultsAdapter;

import java.util.ArrayList;
import java.util.List;


public class PhotosFragment extends Fragment {


    private View view;
    private GeoDataClient mGeoDataClient;
    private NearbyResultItemUtility item;
    private RecyclerView mRecyclerView;
    private MyPhotosAdapter mAdapter;
    private List<PlacePhotoMetadata> photoList;
    private ArrayList<Bitmap> bitmapList;
    private TextView no_photos;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_photos, container, false);
        // Construct a GeoDataClient.
        mGeoDataClient = Places.getGeoDataClient(getActivity(), null);
        bitmapList = new ArrayList<>();
        no_photos = view.findViewById(R.id.no_photos);

//        String id = getData();
//        photoList = new ArrayList<>();
//        bitmapList = new ArrayList<>();
//        getPhotos(id);


        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        try{
            if(getUserVisibleHint()){//界面可见时
                bitmapList.addAll(((PlaceDetailsActivity)getActivity()).getBitmapList());
                if (bitmapList.size() > 0) {
                    setRecyclerView(bitmapList);
                    no_photos.setVisibility(View.INVISIBLE);
                } else {
                    no_photos.setVisibility(View.VISIBLE);
                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

//    private String getData() {
//        Bundle bundle = getActivity().getIntent().getExtras();
//        if (bundle != null) {
//
//            String item_str = bundle.getString("item", null);
//            item = new Gson().fromJson(item_str, NearbyResultItemUtility.class);
//        }
//        return item.getPlaceId();
//
//    }

//    // Request photos and metadata for the specified place.
//    private void getPhotos(final String placeId) {
//
//        Task<PlacePhotoMetadataResponse> photoMetadataResponse = mGeoDataClient.getPlacePhotos(placeId);
//        photoMetadataResponse.addOnCompleteListener(new OnCompleteListener<PlacePhotoMetadataResponse>() {
//            @Override
//            public void onComplete(@NonNull Task<PlacePhotoMetadataResponse> task) {
//                // Get the list of photos.
//                PlacePhotoMetadataResponse photos = task.getResult();
//                // Get the PlacePhotoMetadataBuffer (metadata for all of the photos).
//                PlacePhotoMetadataBuffer photoMetadataBuffer = photos.getPhotoMetadata();
//                for (PlacePhotoMetadata placePhotoMetadata : photoMetadataBuffer) {
//                    photoList.add(placePhotoMetadata);
//                }
//                setRecyclerView();
//            }
//        });
//
//
//    }

    // Set recyclerView
    private void setRecyclerView(ArrayList<Bitmap> bitmapList) {
        mRecyclerView = (RecyclerView) view.findViewById(R.id.photo_recyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
//        mRecyclerView.setAdapter(mAdapter = new MyPhotosAdapter(photoList, mGeoDataClient));
        mRecyclerView.setAdapter(mAdapter = new MyPhotosAdapter(bitmapList));
    }
}
