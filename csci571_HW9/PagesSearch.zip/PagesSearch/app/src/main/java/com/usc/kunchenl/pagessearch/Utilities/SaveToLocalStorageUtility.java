package com.usc.kunchenl.pagessearch.Utilities;

import android.app.Activity;
import android.content.SharedPreferences;

import java.util.Map;

public class SaveToLocalStorageUtility {

    private Activity activity;
    private static final String SHAREDPREFERENCESNAME = "favorite_items";
    private SharedPreferences sp;
    private SharedPreferences.Editor editor;
    private static final String DEFAULTVAL = "null";

    public SaveToLocalStorageUtility(Activity activity) {
        this.activity = activity;
        sp = this.activity.getSharedPreferences(SHAREDPREFERENCESNAME, Activity.MODE_PRIVATE);
        editor = sp.edit();
    }

    public void putInStorage(String id, String data) {
        editor.putString(id, data).apply();
    }


    public String getInStorage(String id) {
        return sp.getString(id, DEFAULTVAL);
    }

    public boolean checkExist(String id) {
        if (getInStorage(id) != DEFAULTVAL) {
            return true;
        }
        return false;
    }

    public void removeFromStorage(String id) {
        editor.remove(id).apply();
    }

    public Map<String, ?> getAll() {
        return sp.getAll();
    }
}
