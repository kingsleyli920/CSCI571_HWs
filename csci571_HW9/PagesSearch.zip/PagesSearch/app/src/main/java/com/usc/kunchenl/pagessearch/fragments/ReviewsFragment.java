package com.usc.kunchenl.pagessearch.fragments;

import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.ReviewsUtility;
import com.usc.kunchenl.pagessearch.Utilities.URLRequestUtility;
import com.usc.kunchenl.pagessearch.activities.PlaceDetailsActivity;
import com.usc.kunchenl.pagessearch.myAdapter.MyReviewsAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class ReviewsFragment extends Fragment implements AdapterView.OnItemSelectedListener {

    /*
     *http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/yelp/best_match?
     * city=Los%20Angeles%20County&state=CA&country=US&name=KFC&addr1=1400%20Glendale%20Blvd,%20Los%20Angeles,%20CA%2090026,%20USA
     * */
    private View view;
    private TextView no_reviews;
    private ReviewsUtility reviewsUtility;
    private List<ReviewsUtility> googleReviews;
    private List<ReviewsUtility> yelpReviews;
    private RecyclerView recyclerView;
    private MyReviewsAdapter mAdapter;
    private LayoutInflater inflater;
    private ViewGroup container;
    private static String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final int MILLITIME_CONVERT_TO_SECTIME_FACTOR = 1000;
    private Spinner reviewsSpinner;
    private Spinner orderSpinner;
    private List<ReviewsUtility> sortedListofrGoogleReviews;
    private List<ReviewsUtility> sortedListofrYelpReviews;
    private int flag = 0;
    private int haveRan = 0;
    private int noGoogleData = 0;
    private int noYelpData = 0;
    private static final String GET_REVIEWS = "http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/yelp/reviews?id=";
//    private String yelp_place_id;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        this.inflater = inflater;
        this.container = container;
        view = this.inflater.inflate(R.layout.fragment_reviews, this.container, false);
        googleReviews = new ArrayList<>();
        yelpReviews = new ArrayList<>();
        sortedListofrGoogleReviews = new ArrayList<>();
        sortedListofrYelpReviews = new ArrayList<>();
        no_reviews = view.findViewById(R.id.no_reviews);
        haveRan = 1;
        reviewsSpinner = (Spinner) view.findViewById(R.id.reviews_company);
        orderSpinner = (Spinner) view.findViewById(R.id.reviews_sort);

        reviewsSpinner.setOnItemSelectedListener(this);
        orderSpinner.setOnItemSelectedListener(this);

        googleReviews = extractAndSaveGoogleData();
        setUpRecyclerView(googleReviews);
        return view;
    }

    private void setUpRecyclerView(List<ReviewsUtility> list) {
        recyclerView = (RecyclerView) view.findViewById(R.id.reviews_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(mAdapter = new MyReviewsAdapter(list));
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private List<ReviewsUtility> extractAndSaveGoogleData() {
        JsonArray arr = getDeliveredJson();
        List<ReviewsUtility> list = new ArrayList<>();
        if (arr != null && arr.size() > 0) {

            String author_name = "";
            String author_url = "";
            String language = "";
            String profile_photo_url = "";
            String rating = "";
            String relative_time_description = "";
            String text = "";
            long time = 0;
            for (JsonElement element : arr) {
                JsonObject eleObj = new ConvertToJsonObj(element.toString()).convertToJson();
                if (eleObj.has("author_name"))
                    author_name = eleObj.get("author_name").toString();
                if (eleObj.has("author_url"))
                    author_url = eleObj.get("author_url").toString();
                if (eleObj.has("language"))
                    language = eleObj.get("language").toString();
                if (eleObj.has("profile_photo_url"))
                    profile_photo_url = eleObj.get("profile_photo_url").toString();
                if (eleObj.has("rating"))
                    rating = eleObj.get("rating").toString();
                if (eleObj.has("relative_time_description"))
                    relative_time_description = eleObj.get("relative_time_description").toString();
                if (eleObj.has("text"))
                    text = eleObj.get("text").toString();
                if (eleObj.has("time"))
                    time = Integer.parseInt(eleObj.get("time").toString());
                reviewsUtility = new ReviewsUtility();
                reviewsUtility.setAuthor_name(author_name);
                reviewsUtility.setAuthor_url(author_url);
                reviewsUtility.setLanguage(language);
                reviewsUtility.setProfile_photo_url(profile_photo_url);
                reviewsUtility.setRating(rating);
                reviewsUtility.setRelative_time_description(relative_time_description);
                reviewsUtility.setText(text);
                reviewsUtility.setTime(time);
                String formatted_time = convert2String(time * MILLITIME_CONVERT_TO_SECTIME_FACTOR);
                //System.out.println("formatted_time" + formatted_time);
                reviewsUtility.setFormatted_time(formatted_time);
                list.add(reviewsUtility);
            }
        } else {
            noGoogleData = 1;
            no_reviews.setVisibility(View.VISIBLE);
        }
        return list;

    }

    private JsonArray getDeliveredJson() {
        Bundle bundle = getActivity().getIntent().getExtras();

        if (bundle != null) {
            String responseData = bundle.getString("jsonResponse");
            JsonObject jsonObject = new ConvertToJsonObj(responseData).convertToJson();
            JsonObject jsonObject_result = jsonObject.getAsJsonObject("result");
            JsonArray reviews_arr = jsonObject_result.getAsJsonArray("reviews");
            return reviews_arr;
        }
        return null;
    }

    // Function used to convert long integer to formatted time

    @RequiresApi(api = Build.VERSION_CODES.N)
    private static String convert2String(long time) {
        if (time > 0l) {
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
            calendar.setTimeInMillis(time);
            return sdf.format(calendar.getTime());
        }
        return "";
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String date2TimeStamp(String date_str) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
            return String.valueOf(sdf.parse(date_str).getTime() / 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) {
            case R.id.reviews_company:
                if (position == 0 && noGoogleData != 1) {
                    no_reviews.setVisibility(View.INVISIBLE);
                    recyclerView.setVisibility(View.VISIBLE);
                    setUpRecyclerView(googleReviews);
                    flag = 0;
                    orderSpinner.setSelection(0, true);
                } else if (position == 0 && noGoogleData != 0) {
                    no_reviews.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.INVISIBLE);
                    flag = 0;
                    orderSpinner.setSelection(0, true);
                } else if (position == 1 && noYelpData != 1) {
                    flag = 1;
                    String yelpPlaceId = ((PlaceDetailsActivity) getActivity()).getYelpPlaceId();
                    String reviews_url = GET_REVIEWS + yelpPlaceId;
                    String head = "{\n" +
                            "  \"reviews\": [";
                    String tail = "],\n" +
                            "  \"total\": 3,\n" +
                            "  \"possible_languages\": [\"en\"]\n" +
                            "}\n";
                    URLRequestUtility urlRequestUtility = new URLRequestUtility();
                    try {
                        urlRequestUtility.startConnection(reviews_url
                                , new URLRequestUtility.NetworkResponse() {
                                    @Override
                                    public void onSuccess(final String body) {
                                        final String response = body;

                                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                                            public void run() {
                                                try {
                                                    String center = response.substring(1, response.length() - 1);
                                                    String wholeStr = head + center + tail;
                                                    if (wholeStr.contains("error")) {
                                                        no_reviews.setVisibility(View.VISIBLE);
                                                        recyclerView.setVisibility(View.INVISIBLE);
                                                        noYelpData = 1;
                                                    } else {
                                                        JsonObject jsonObject = new ConvertToJsonObj(wholeStr).convertToJson();
                                                        //TODO if statement to judge if there is no review
                                                        JsonArray reviews = jsonObject.getAsJsonArray("reviews");
                                                        if (reviews.size() == 0) {
                                                            no_reviews.setVisibility(View.VISIBLE);
                                                            recyclerView.setVisibility(View.INVISIBLE);
                                                            noYelpData = 1;
                                                        } else {
                                                            no_reviews.setVisibility(View.INVISIBLE);
                                                            recyclerView.setVisibility(View.VISIBLE);
                                                            for (JsonElement jsonElement : reviews) {
                                                                JsonObject jsonObj = new ConvertToJsonObj(jsonElement.toString()).convertToJson();
                                                                String author_url = String.valueOf(jsonObj.get("url"));
                                                                String text = String.valueOf(jsonObj.get("text"));
                                                                String rating = String.valueOf(jsonObj.get("rating"));
                                                                String formatted_time = String.valueOf(jsonObj.get("time_created"));
                                                                JsonObject user = jsonObj.getAsJsonObject("user");
                                                                String profile_photo_url = String.valueOf(user.get("image_url"));
                                                                String author_name = String.valueOf(user.get("name"));
                                                                String timeStr = date2TimeStamp(formatted_time.replace("\"", ""));
                                                                long time = Integer.parseInt(timeStr);
                                                                reviewsUtility = new ReviewsUtility();
                                                                reviewsUtility.setAuthor_name(author_name);
                                                                reviewsUtility.setAuthor_url(author_url);
                                                                reviewsUtility.setLanguage("");
                                                                reviewsUtility.setProfile_photo_url(profile_photo_url);
                                                                reviewsUtility.setRating(rating);
                                                                reviewsUtility.setRelative_time_description("");
                                                                reviewsUtility.setText(text);
                                                                reviewsUtility.setTime(time);
                                                                reviewsUtility.setFormatted_time(formatted_time);
                                                                yelpReviews.add(reviewsUtility);
                                                            }
                                                            orderSpinner.setSelection(0, true);
                                                            setUpRecyclerView(yelpReviews);
                                                        }
                                                    }


                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }


                                            }
                                        });


                                    }

                                    @Override
                                    public void onFailure() {
                                        System.out.println("failed");
                                    }
                                });
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("finish");
                } else if (position == 1 && noYelpData != 0) {
                    no_reviews.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.INVISIBLE);
                    flag = 1;
                    orderSpinner.setSelection(0, true);
                }

                break;
            case R.id.reviews_sort:

                if (flag == 0 && haveRan == 1) {
                    if (position == 0) {
                        sortedListofrGoogleReviews = googleReviews;
                        setUpRecyclerView(sortedListofrGoogleReviews);
                    } else if (position == 1) {
                        sortedListofrGoogleReviews = googleReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getRating).
                                        reversed()).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrGoogleReviews);
                    } else if (position == 2) {
                        sortedListofrGoogleReviews = googleReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getRating)).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrGoogleReviews);
                    } else if (position == 3) {
                        sortedListofrGoogleReviews = googleReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getTime).
                                        reversed()).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrGoogleReviews);
                    } else if (position == 4) {
                        sortedListofrGoogleReviews = googleReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getTime)).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrGoogleReviews);
                    }
                } else if (flag == 1 && haveRan == 1) {
                    if (position == 0) {
                        sortedListofrYelpReviews = yelpReviews;
                        setUpRecyclerView(sortedListofrYelpReviews);
                    } else if (position == 1) {
                        sortedListofrYelpReviews = yelpReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getRating).
                                        reversed()).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrYelpReviews);
                    } else if (position == 2) {
                        sortedListofrYelpReviews = yelpReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getRating)).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrYelpReviews);
                    } else if (position == 3) {
                        sortedListofrYelpReviews = yelpReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getTime).
                                        reversed()).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrYelpReviews);
                    } else if (position == 4) {
                        sortedListofrYelpReviews = yelpReviews.stream().
                                sorted(Comparator.comparing(ReviewsUtility::getTime)).collect(Collectors.toList());
                        setUpRecyclerView(sortedListofrYelpReviews);
                    }
                }
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}