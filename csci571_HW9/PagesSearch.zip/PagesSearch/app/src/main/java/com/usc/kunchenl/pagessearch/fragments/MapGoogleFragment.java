package com.usc.kunchenl.pagessearch.fragments;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.maps.DirectionsApi;
import com.google.maps.GeoApiContext;
import com.google.maps.android.PolyUtil;
import com.google.maps.errors.ApiException;
import com.google.maps.model.Bounds;
import com.google.maps.model.DirectionsResult;
import com.google.maps.model.DirectionsRoute;
import com.google.maps.model.TravelMode;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.URLRequestUtility;
import com.usc.kunchenl.pagessearch.myAdapter.MyAutocompleteAdapter;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class MapGoogleFragment extends Fragment implements
        OnMapReadyCallback, View.OnFocusChangeListener {


    private View view;
    private GoogleMap mMap;
    private AutoCompleteTextView from;
    private Spinner mode;
    private NearbyResultItemUtility item;
    private static final String GEOCODING_KEY = "AIzaSyClc3RMqH7MedLBTsgvtbwiXtqrl8RthDU";
    private LatLng origin_loc;
    private LatLng dest_loc;
    private static final int overview = 0;
    private String travel_mode;
    private SupportMapFragment mapFragment;
    private MapGoogleFragment mapGoogleFragment = this;
    private Fragment map;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_map, container, false);
        //Check if Google Play Services Available or not

        if (!CheckGooglePlayServices()) {
            Log.d("onCreate", "Finishing test case since Google Play Services are not available");
            getActivity().finish();
        } else {
            Log.d("onCreate", "Google Play Services available.");
        }
        // Set views
        from = view.findViewById(R.id.from);
        mode = view.findViewById(R.id.travel_mode);
        origin_loc = getCurrentLocation();
        dest_loc = getDestLocation();
        //System.out.println(origin_loc);
        travel_mode = mode.getSelectedItem().toString();
        mode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                travel_mode = parent.getItemAtPosition(position).toString();
                if (mMap != null)
                    mMap.clear();
                mapFragment = (SupportMapFragment) mapGoogleFragment.getChildFragmentManager()
                        .findFragmentById(R.id.map);
                mapFragment.getMapAsync(mapGoogleFragment);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        from.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    // Your piece of code on keyboard search click
                    getOriginLocation();
                    from.clearFocus();
                    InputMethodManager in = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    in.hideSoftInputFromWindow(from.getWindowToken(), 0);

                    return true;
                }
                return false;
            }
        });
        // Custom Autocomplete
        MyAutocompleteAdapter adapter = new MyAutocompleteAdapter(getContext());
        from.setAdapter(adapter);
        // Set map fragment
        mapFragment = (SupportMapFragment) this.getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        return view;

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;
        setupGoogleMapScreenSettings(googleMap);
//        DirectionsResult results = getDirectionsDetails("483 George St, Sydney NSW 2000, Australia","182 Church St, Parramatta NSW 2150, Australia",TravelMode.DRIVING);


        DirectionsResult directionsResult;

        directionsResult = getDirectionResult(origin_loc, dest_loc, travel_mode);
        if (directionsResult != null) {
            addPolyline(directionsResult, googleMap);
            MarkerOptions origin_mark = new MarkerOptions().position(new LatLng(directionsResult.routes[0].legs[0].startLocation.lat, directionsResult.routes[0].legs[0].startLocation.lng)).title(directionsResult.routes[0].legs[0].startAddress);
            MarkerOptions dest_mark = new MarkerOptions().position(new LatLng(directionsResult.routes[0].legs[0].endLocation.lat, directionsResult.routes[0].legs[0].endLocation.lng)).title(directionsResult.routes[0].legs[0].startAddress).snippet(getEndLocationTitle(directionsResult));
            mMap.addMarker(origin_mark);
            mMap.addMarker(dest_mark);
            LatLngBounds.Builder builder = new LatLngBounds.Builder();

            builder.include(origin_mark.getPosition());
            builder.include(dest_mark.getPosition());
            LatLngBounds bounds = builder.build();
            int padding = 100; // offset from edges of the map in pixels
            CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
            mMap.animateCamera(cu);
        }

        System.out.println("map is ready");
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        getOriginLocation();
    }

    private LatLng getCurrentLocation() {
        LocationManager locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();

        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return null;
        }
        Location location = locationManager.getLastKnownLocation(locationManager.getBestProvider(criteria, false));
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        LatLng myLoc = new LatLng(latitude, longitude);
        return myLoc;
    }

    private LatLng getDestLocation() {
        Bundle bundle = getActivity().getIntent().getExtras();

        // Get Clicked item
        if (bundle != null) {

            String item_str = bundle.getString("item", null);
            item = new Gson().fromJson(item_str, NearbyResultItemUtility.class);
        }

        double dest_lat = Double.parseDouble(item.getLat());
        double dest_lng = Double.parseDouble(item.getLng());
        LatLng dest_loc = new LatLng(dest_lat, dest_lng);
        return dest_loc;
    }

    private boolean CheckGooglePlayServices() {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable(getContext());
        if (result != ConnectionResult.SUCCESS) {
            if (googleAPI.isUserResolvableError(result)) {
                googleAPI.getErrorDialog(getActivity(), result,
                        0).show();
            }
            return false;
        }
        return true;
    }

    private DirectionsResult getDirectionResult(LatLng original, LatLng dest, String mode) {
        TravelMode MODE;

        switch (mode) {
            case "Driving":
                MODE = TravelMode.DRIVING;
                break;
            case "Bicycling":
                MODE = TravelMode.BICYCLING;
                break;
            case "Walking":
                MODE = TravelMode.WALKING;
                break;
            case "Transit":
                MODE = TravelMode.TRANSIT;
                break;
            default:
                MODE = TravelMode.UNKNOWN;
                break;
        }
        System.out.println(mode);
//        System.out.println(MODE);
//        System.out.println(TravelMode.WALKING);
        String origin = original.latitude + "," + original.longitude;
        String destination = dest.latitude + "," + dest.longitude;
        //System.out.println(origin + " : " + destination);
        try {
            return DirectionsApi.newRequest(getGeoContext())
                    .mode(MODE)
                    .origin(origin)
                    .destination(destination)
                    .await();
        } catch (ApiException e) {
            Toast.makeText(getContext(), "Get routes failed!!!", Toast.LENGTH_SHORT);
            e.printStackTrace();
        } catch (InterruptedException e) {
            Toast.makeText(getContext(), "Get routes failed!!!", Toast.LENGTH_SHORT);
            e.printStackTrace();
        } catch (IOException e) {
            Toast.makeText(getContext(), "Get routes failed!!!", Toast.LENGTH_SHORT);
            e.printStackTrace();
        }
        return null;
    }

    private void getOriginLocation() {
        String input_loc = this.from.getText().toString();
        String urlWithParams = "https://maps.googleapis.com/maps/api/geocode/json?address=" + URLEncoder.encode(input_loc) + "&key=" + URLEncoder.encode(GEOCODING_KEY);
        URLRequestUtility urlRequestUtility = new URLRequestUtility();
        try {
            urlRequestUtility.startConnection(urlWithParams, new URLRequestUtility.NetworkResponse() {
                @Override
                public void onSuccess(String body) {
                    final String jsonResponse = body;
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        public void run() {
                            JsonObject jsonObject = new ConvertToJsonObj(jsonResponse).convertToJson();
                            JsonArray results = jsonObject.getAsJsonArray("results");
                            String results_value = String.valueOf(results.get(0));
                            JsonObject innerJson = new ConvertToJsonObj(results_value).convertToJson();
                            JsonObject geometry = innerJson.getAsJsonObject("geometry");
                            JsonObject location = geometry.get("location").getAsJsonObject();
                            double origin_lat = Double.parseDouble(String.valueOf(location.get("lat")));
                            double origin_lng = Double.parseDouble(String.valueOf(location.get("lng")));
                            System.out.println(origin_lat + ":" + origin_lng);
                            origin_loc = new LatLng(origin_lat, origin_lng);
                            if (mMap != null)
                                mMap.clear();
                            mapFragment = (SupportMapFragment) mapGoogleFragment.getChildFragmentManager()
                                    .findFragmentById(R.id.map);
                            mapFragment.getMapAsync(mapGoogleFragment);
                        }
                    });
                }

                @Override
                public void onFailure() {
                    System.out.println("failed");
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private GeoApiContext getGeoContext() {
        GeoApiContext geoApiContext = new GeoApiContext();
        return geoApiContext.setQueryRateLimit(3).
                setApiKey(getString(R.string.directionApiKey)).
                setConnectTimeout(1, TimeUnit.SECONDS).
                setReadTimeout(1, TimeUnit.SECONDS).
                setWriteTimeout(1, TimeUnit.SECONDS);
    }

    private void addPolyline(DirectionsResult results, GoogleMap mMap) {
        List<LatLng> decodedPath = PolyUtil.decode(results.routes[0].overviewPolyline.getEncodedPath());
        mMap.addPolyline(new PolylineOptions().addAll(decodedPath).color(Color.BLUE));
    }

    private void setupGoogleMapScreenSettings(GoogleMap mMap) {
        mMap.setBuildingsEnabled(true);
        mMap.setIndoorEnabled(true);
        mMap.setTrafficEnabled(false);
        UiSettings mUiSettings = mMap.getUiSettings();
        mUiSettings.setZoomControlsEnabled(true);
        mUiSettings.setCompassEnabled(true);
        mUiSettings.setMyLocationButtonEnabled(true);
        mUiSettings.setScrollGesturesEnabled(true);
        mUiSettings.setZoomGesturesEnabled(true);
        mUiSettings.setTiltGesturesEnabled(true);
        mUiSettings.setRotateGesturesEnabled(true);
    }

    private String getEndLocationTitle(DirectionsResult results) {
        return "Time :" + results.routes[overview].legs[overview].duration.humanReadable + " Distance :" + results.routes[overview].legs[overview].distance.humanReadable;
    }


}