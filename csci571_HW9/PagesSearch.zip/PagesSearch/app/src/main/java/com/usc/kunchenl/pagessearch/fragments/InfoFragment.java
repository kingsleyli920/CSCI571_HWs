package com.usc.kunchenl.pagessearch.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.activities.PlaceDetailsActivity;


public class InfoFragment extends Fragment {


    private View view;
    private TextView address_txt, address, phone_txt, phone, price_level_txt,
            price_level, rating_txt, google_page_txt, google_page, website_txt, website;
    private RatingBar rating;

    private NearbyResultItemUtility item;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_info, container, false);

        initViews();
        item = ((PlaceDetailsActivity)this.getActivity()).getData();
        setViewValues();
        return view;
    }

    private void initViews() {
        address_txt = (TextView) view.findViewById(R.id.address_txt);
        address = (TextView) view.findViewById(R.id.address);
        phone_txt = (TextView) view.findViewById(R.id.phone_txt);
        phone = (TextView) view.findViewById(R.id.phone);
        price_level_txt = (TextView) view.findViewById(R.id.price_txt);
        price_level = (TextView) view.findViewById(R.id.price);
        rating_txt = (TextView) view.findViewById(R.id.rating_txt);
        rating = (RatingBar) view.findViewById(R.id.rating);
        google_page_txt = (TextView) view.findViewById(R.id.google_page_txt);
        google_page = (TextView) view.findViewById(R.id.google_page);
        website_txt = (TextView) view.findViewById(R.id.website_txt);
        website = (TextView) view.findViewById(R.id.website);
    }

    private void setViewValues() {
        String address = item.getFormatted_address().replace("\"", "");
        String phone = item.getFormatted_phone_number().replace("\"", "");
        String price_level = item.getPrice_level().replace("\"", "");
        String rating = item.getRating().replace("\"", "");
        String url = item.getUrl().replace("\"", "");
        String website = item.getWebsite().replace("\"", "");

        this.address.setText(address);
        this.phone.setText(phone);
        int lv = Integer.parseInt(price_level);
        String text = "$";
        String price = new String(new char[lv]).replace("\0", text);
        this.price_level.setText(price);
        this.google_page.setText(url);
        this.website.setText(website);

        this.rating.setRating(Float.parseFloat(rating));

        System.out.println(address + phone + price_level + rating + url + website);

    }
}
