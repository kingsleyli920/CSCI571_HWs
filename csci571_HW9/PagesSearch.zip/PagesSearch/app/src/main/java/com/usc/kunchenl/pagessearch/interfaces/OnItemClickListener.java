package com.usc.kunchenl.pagessearch.interfaces;

import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.ReviewsUtility;

//TODO fix issues of two buttons
public interface OnItemClickListener {
    void onItemClick(NearbyResultItemUtility item);
    void onItemClick(NearbyResultItemUtility item, int postion);

    void onItemClick(ReviewsUtility item);
    void onItemClick(ReviewsUtility item, int postion);
}
