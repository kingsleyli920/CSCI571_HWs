package com.usc.kunchenl.pagessearch.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.google.gson.Gson;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.ReviewsUtility;
import com.usc.kunchenl.pagessearch.Utilities.SaveToLocalStorageUtility;
import com.usc.kunchenl.pagessearch.Utilities.URLRequestUtility;
import com.usc.kunchenl.pagessearch.activities.PlaceDetailsActivity;
import com.usc.kunchenl.pagessearch.activities.SearchActivity;
import com.usc.kunchenl.pagessearch.interfaces.OnItemClickListener;
import com.usc.kunchenl.pagessearch.myAdapter.MyFavoritesAdapter;
import com.usc.kunchenl.pagessearch.myAdapter.MyResultsAdapter;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Map;


public class FavoriteFragment extends Fragment {

    //TODO fixed error in favorites delete
    private View view;
    private MyFavoritesAdapter mAdapter;
    private SaveToLocalStorageUtility saveToLocalStorageUtility;
    private Map<String, ?> localData;

    private TextView noFavoriteTxt;
    private RecyclerView recyclerView;
    private LayoutInflater inflater;

    private ViewGroup container;

    private TextView progress_bar_text;
    private ProgressBar progressBar;
    private ConstraintLayout progress_bar_layout;

    private static final String GET_DETAILS_URL = "http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/place/details?place_id=";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        this.inflater = inflater;
        this.container = container;
        view = this.inflater.inflate(R.layout.fragment_favorites, this.container, false);
        progress_bar_layout = (ConstraintLayout) view.findViewById(R.id.progress_bar_include);
        progress_bar_text = (TextView) view.findViewById(R.id.progress_bar_text);
        progress_bar_layout.setVisibility(View.INVISIBLE);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        noFavoriteTxt = getActivity().findViewById(R.id.no_favorites);
        recyclerView = getActivity().findViewById(R.id.id_recyclerview);
        if (hasLocalStorage()) {
            noFavoriteTxt.setVisibility(View.INVISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            showLocalData();

        } else {
            noFavoriteTxt.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.INVISIBLE);
        }
    }

    private void showLocalData() {
        recyclerView = (RecyclerView) getActivity().findViewById(R.id.id_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(mAdapter = new MyFavoritesAdapter((AppCompatActivity) getActivity(), localData, new OnItemClickListener() {
            @Override
            public void onItemClick(final NearbyResultItemUtility item) {
                final String place_id = item.getPlaceId();
                final String name = item.getName();
                String url = GET_DETAILS_URL + URLEncoder.encode(place_id);
                progress_bar_text.setText("Fetching Result");
                progress_bar_layout.setVisibility(View.VISIBLE);
                URLRequestUtility urlRequestUtility = new URLRequestUtility();
                try {
                    urlRequestUtility.startConnection(url, new URLRequestUtility.NetworkResponse() {
                        @Override
                        public void onSuccess(final String body) {
                            final String jsonResponse = body;
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    progress_bar_layout.setVisibility(View.INVISIBLE);
                                    Intent intent = new Intent(getActivity(), PlaceDetailsActivity.class);
                                    intent.putExtra("page_title", name);
                                    intent.putExtra("jsonResponse", jsonResponse);
                                    intent.putExtra("item", new Gson().toJson(item));
                                    intent.putExtra("jsonData", localData.get(place_id).toString());
                                    startActivity(intent);
                                }
                            });
                        }

                        @Override
                        public void onFailure() {
                            System.out.println("failed");
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onItemClick(NearbyResultItemUtility item, int postion) {

            }

            @Override
            public void onItemClick(ReviewsUtility item) {

            }

            @Override
            public void onItemClick(ReviewsUtility item, int postion) {

            }

        }));
    }

    private boolean hasLocalStorage() {
        saveToLocalStorageUtility = new SaveToLocalStorageUtility(getActivity());
        localData = saveToLocalStorageUtility.getAll();
        if (localData.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }
}
