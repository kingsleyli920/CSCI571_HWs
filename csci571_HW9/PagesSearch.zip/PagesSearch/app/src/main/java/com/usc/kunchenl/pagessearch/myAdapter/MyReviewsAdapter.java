package com.usc.kunchenl.pagessearch.myAdapter;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.ReviewsUtility;
import com.usc.kunchenl.pagessearch.interfaces.OnItemClickListener;

import java.util.ArrayList;
import java.util.List;


public class MyReviewsAdapter extends RecyclerView.Adapter<MyReviewsAdapter.MyViewHolder> implements OnItemClickListener {

    private AppCompatActivity activity;
    private List<ReviewsUtility> myData;
    private TextView author_name;
    private RatingBar rating;
    private TextView time;
    private TextView text;
    private ImageView profile_url;
    private ReviewsUtility reviewsUtility;

    public MyReviewsAdapter(List<ReviewsUtility> list) {
        myData = new ArrayList<>();
        myData.addAll(list);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        this.activity = (AppCompatActivity) parent.getContext();
        View view = LayoutInflater.from(activity).inflate(R.layout.reviews_layout, parent, false);

        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        reviewsUtility = myData.get(position);
        holder.bind(reviewsUtility, this);
    }

    @Override
    public int getItemCount() {
        return myData.size();
    }

    @Override
    public void onItemClick(NearbyResultItemUtility item) {

    }

    @Override
    public void onItemClick(NearbyResultItemUtility item, int postion) {

    }

    @Override
    public void onItemClick(ReviewsUtility item) {

        // Remove first and last "
        if (item.getAuthor_url() != null || item.getAuthor_url() != "") {
            Uri uri = Uri.parse(item.getAuthor_url().substring(1, item.getAuthor_url().length() - 1)); // missing 'http://' will cause crashed
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            activity.startActivity(intent);
        } else {
            Toast.makeText(activity, "This person doesn't have a personal page", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onItemClick(ReviewsUtility item, int postion) {

    }


    class MyViewHolder extends RecyclerView.ViewHolder {


        public MyViewHolder(View view) {

            super(view);
            author_name = (TextView) view.findViewById(R.id.name_review);
            rating = (RatingBar) view.findViewById(R.id.rating_review);
            time = (TextView) view.findViewById(R.id.time_review);
            text = (TextView) view.findViewById(R.id.comment_review);
            profile_url = (ImageView) view.findViewById(R.id.profile_review);

        }

        private void bind(ReviewsUtility reviewsUtility, final OnItemClickListener listener) {
            RequestOptions options = new RequestOptions()
                    .centerCrop()
                    .placeholder(R.mipmap.ic_launcher_round)
                    .error(R.mipmap.ic_launcher_round);


            author_name.setText(reviewsUtility.getAuthor_name());
            rating.setRating(Float.parseFloat(reviewsUtility.getRating()));
            time.setText(reviewsUtility.getFormatted_time());
            text.setText(reviewsUtility.getText());
            Glide.with(activity).load(reviewsUtility.getProfile_photo_url().replace("\"", "")).apply(options).into(profile_url);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(reviewsUtility);
                }
            });
        }

    }

}
