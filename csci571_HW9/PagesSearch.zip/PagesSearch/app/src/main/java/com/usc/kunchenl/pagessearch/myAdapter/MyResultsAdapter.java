package com.usc.kunchenl.pagessearch.myAdapter;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.ExecuteNearbyResponse;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.ReviewsUtility;
import com.usc.kunchenl.pagessearch.Utilities.SaveToLocalStorageUtility;
import com.usc.kunchenl.pagessearch.Utilities.URLRequestUtility;
import com.usc.kunchenl.pagessearch.activities.PlaceDetailsActivity;
import com.usc.kunchenl.pagessearch.activities.SearchActivity;
import com.usc.kunchenl.pagessearch.interfaces.OnItemClickListener;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MyResultsAdapter extends RecyclerView.Adapter<MyResultsAdapter.MyViewHolder> implements View.OnClickListener, OnItemClickListener{



    private AppCompatActivity searchActivity;
    private JsonArray mDatas;
    private List<String> localData;
    private ImageView icon;
    private TextView name;
    private TextView vicinity;
    private NearbyResultItemUtility nearbyResultItemUtility;
    private ImageView favorite_img;
    private List<NearbyResultItemUtility> extractedData;
    private SaveToLocalStorageUtility saveToLocalStorageUtility;
    private RecyclerView recyclerView;
    private static final String GET_DETAILS_URL = "http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/place/details?place_id=";


    public MyResultsAdapter(JsonArray mDatas, List<String> localData) {
        this.mDatas = mDatas;
        this.localData = localData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        this.searchActivity = (AppCompatActivity) parent.getContext();
        View view = LayoutInflater.from(searchActivity).inflate(R.layout.result_item, parent, false);
        favorite_img = (ImageView) view.findViewById(R.id.favorite_btn);
        saveToLocalStorageUtility = new SaveToLocalStorageUtility(searchActivity);
        MyViewHolder holder = new MyViewHolder(view, favorite_img);
        System.out.println(mDatas.get(0));
        return holder;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        extractedData = new ExecuteNearbyResponse().extractAndSetData(mDatas);
        nearbyResultItemUtility = extractedData.get(position);
        holder.bind(nearbyResultItemUtility, this);
        if (isLocalData(nearbyResultItemUtility.getPlaceId())) {
            //System.out.println(nearbyResultItemUtility.getPlaceId() + "in local");
            holder.imageView.setBackgroundResource(R.drawable.heart_fill_red);
        } else {
            //System.out.println(nearbyResultItemUtility.getPlaceId() + "not in local");
            holder.imageView.setBackgroundResource(R.drawable.heart_outline_black);
        }

    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }


    // Check data whether stored in local
    private boolean isLocalData(String place_id) {

        if (localData.size() > 0) {
            for (String key : localData) {
                if (key.equals(place_id)) {
                    return true;
                }

            }

        }
        return false;
    }

    @Override
    public void onClick(View v) {
        System.out.println("clicked");
    }


    @Override
    public void onItemClick(NearbyResultItemUtility item) {

    }

    @Override
    public void onItemClick(final NearbyResultItemUtility item, final int position) {
        final String place_id = item.getPlaceId();
        final String name = item.getName();
        String url = GET_DETAILS_URL + URLEncoder.encode(place_id);
        URLRequestUtility urlRequestUtility = new URLRequestUtility();
        try {
            urlRequestUtility.startConnection(url, new URLRequestUtility.NetworkResponse() {
                @Override
                public void onSuccess(final String body) {
                    final String jsonResponse = body;
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        public void run() {
                            Intent intent = new Intent(searchActivity, PlaceDetailsActivity.class);
                            intent.putExtra("page_title", name);
                            intent.putExtra("jsonResponse", jsonResponse);
                            intent.putExtra("item", new Gson().toJson(item));
                            intent.putExtra("jsonData",mDatas.get(position).toString());
                            searchActivity.startActivity(intent);
                        }
                    });
                }

                @Override
                public void onFailure() {
                    System.out.println("failed");
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemClick(ReviewsUtility item) {

    }

    @Override
    public void onItemClick(ReviewsUtility item, int postion) {

    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private ImageView imageView;
        private RelativeLayout relativeLayout;

        public MyViewHolder(View view, ImageView imageView) {

            super(view);
            this.imageView = imageView;
            icon = (ImageView) view.findViewById(R.id.icon);
            name = (TextView) view.findViewById(R.id.name);
            vicinity = (TextView) view.findViewById(R.id.vicinity);
            imageView.setOnClickListener(this);
            view.setOnClickListener(this);
        }

        // favorite_btn onclick
        @Override
        public void onClick(View v) {

            // Handle click event for favorite image
            if (v == imageView) {
                String place_id = extractedData.get(getAdapterPosition()).getPlaceId();
                String place_data = mDatas.get(getAdapterPosition()).toString();
                String saveText = extractedData.get(getAdapterPosition()).getName() + " at "
                        + extractedData.get(getAdapterPosition()).getVicinity()
                        + "has been added to favorite list";

                String removeText = extractedData.get(getAdapterPosition()).getName() + " at "
                        + extractedData.get(getAdapterPosition()).getVicinity()
                        + "has been removed from favorite list";
                if (saveToLocalStorageUtility.checkExist(place_id)) {
                    saveToLocalStorageUtility.removeFromStorage(place_id);
                    Toast.makeText(v.getContext(), removeText, Toast.LENGTH_SHORT).show();
                    imageView.setBackgroundResource(R.drawable.heart_outline_black);
                } else {
                    saveToLocalStorageUtility.putInStorage(place_id, place_data);
                    if (saveToLocalStorageUtility.checkExist(place_id)) {
                        Toast.makeText(v.getContext(), saveText, Toast.LENGTH_SHORT).show();
                        imageView.setBackgroundResource(R.drawable.heart_fill_red);
                    } else {
                        Toast.makeText(v.getContext(), "Failed to add item to favorites list, please try again", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }

        public void bind(final NearbyResultItemUtility item, final OnItemClickListener listener) {
            Glide.with(searchActivity).load(nearbyResultItemUtility.getIcon()).into(icon);
            name.setText(nearbyResultItemUtility.getName());
            vicinity.setText(nearbyResultItemUtility.getVicinity());
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(item, getAdapterPosition());
                }
            });
        }

    }
}