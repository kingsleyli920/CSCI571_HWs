package com.usc.kunchenl.pagessearch.myAdapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.usc.kunchenl.pagessearch.fragments.InfoFragment;
import com.usc.kunchenl.pagessearch.fragments.MapGoogleFragment;
import com.usc.kunchenl.pagessearch.fragments.MapGoogleFragment;
import com.usc.kunchenl.pagessearch.fragments.PhotosFragment;
import com.usc.kunchenl.pagessearch.fragments.ReviewsFragment;

public class MyPlaceDetailFragmentsAdapter extends FragmentPagerAdapter {
    private String[] mTitles = new String[]{"INFO", "PHOTOS", "MAP", "REVIEWS"};

    public MyPlaceDetailFragmentsAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        if (position == 0)
            return new InfoFragment();
        else if (position == 1)
            return new PhotosFragment();
        else if (position == 2)
            return new MapGoogleFragment();

        return new ReviewsFragment();
    }

    @Override
    public int getCount() {
        return mTitles.length;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTitles[position];
    }
}
