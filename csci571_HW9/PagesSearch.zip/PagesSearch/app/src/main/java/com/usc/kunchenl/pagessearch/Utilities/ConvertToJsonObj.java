package com.usc.kunchenl.pagessearch.Utilities;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ConvertToJsonObj {

    private String str;

    public ConvertToJsonObj(String str) {
        this.str = str;
    }

    public JsonObject convertToJson() {
        JsonParser parser = new JsonParser();
        JsonObject jsonResults = parser.parse(str).getAsJsonObject();
        return jsonResults;
    }
}
