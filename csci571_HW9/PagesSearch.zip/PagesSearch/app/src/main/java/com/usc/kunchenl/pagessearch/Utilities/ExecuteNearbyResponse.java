package com.usc.kunchenl.pagessearch.Utilities;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExecuteNearbyResponse {

    private List<NearbyResultItemUtility> extractedData;
    private Map<String, String> mapData;

    public ExecuteNearbyResponse() {

    }

    public List<NearbyResultItemUtility> extractAndSetData(JsonArray mDatas) {
        extractedData = new ArrayList<NearbyResultItemUtility>();
        if (mDatas.size() > 0) {
            for (JsonElement arr : mDatas) {
                JsonObject eleJson = new ConvertToJsonObj(arr.toString()).convertToJson();
                JsonObject geometryJson = eleJson.getAsJsonObject("geometry");
                JsonObject locationJson = geometryJson.getAsJsonObject("location");

                // Get location details
                String lat = String.valueOf(locationJson.get("lat")).replace("\"", "");
                String lng = String.valueOf(locationJson.get("lng")).replace("\"", "");
                String placeId = String.valueOf(eleJson.get("place_id")).replace("\"", "");
                String name = String.valueOf(eleJson.get("name")).replace("\"", "");
                String icon = String.valueOf(eleJson.get("icon")).replace("\"", "");
                String vicinity = String.valueOf(eleJson.get("vicinity")).replace("\"", "");
                String price_level = "0";
                String rating = "0";

                if (eleJson.has("price_level")) {
                    price_level = String.valueOf(eleJson.get("price_level")).replace("\"", "");
                }

                if (eleJson.has("rating")) {
                    rating = String.valueOf(eleJson.get("rating")).replace("\"", "");
                }

                // Store location details to object
                NearbyResultItemUtility nearbyResultItemUtility = new NearbyResultItemUtility();
                nearbyResultItemUtility.setPlaceId(placeId);
                nearbyResultItemUtility.setIcon(icon);
                nearbyResultItemUtility.setName(name);
                nearbyResultItemUtility.setVicinity(vicinity);
                nearbyResultItemUtility.setLat(lat);
                nearbyResultItemUtility.setLng(lng);
                nearbyResultItemUtility.setPrice_level(price_level);
                nearbyResultItemUtility.setRating(rating);
                extractedData.add(nearbyResultItemUtility);
//                System.out.println(vicinity);
            }
        }
        return extractedData;
    }

    public Map<String, String> getLocalData(String jsonStr) {

        //System.out.println(jsonStr);
        mapData = new HashMap<>();
        JsonObject eleJson = new ConvertToJsonObj(jsonStr).convertToJson();
        JsonObject geometryJson = eleJson.getAsJsonObject("geometry");
        JsonObject locationJson = geometryJson.getAsJsonObject("location");

        // Get location details
        String lat = String.valueOf(locationJson.get("lat")).replace("\"", "");
        String lng = String.valueOf(locationJson.get("lng")).replace("\"", "");
        String placeId = String.valueOf(eleJson.get("place_id")).replace("\"", "");
        String name = String.valueOf(eleJson.get("name")).replace("\"", "");
        String icon = String.valueOf(eleJson.get("icon")).replace("\"", "");
        String vicinity = String.valueOf(eleJson.get("vicinity")).replace("\"", "");
        String price_level = "0";
        String rating = "0";

        if (eleJson.has("price_level")) {
            price_level = String.valueOf(eleJson.get("price_level")).replace("\"", "");
        }

        if (eleJson.has("rating")) {
            rating = String.valueOf(eleJson.get("rating")).replace("\"", "");
        }

        mapData.put("place_id", placeId);
        mapData.put("lat", lat);
        mapData.put("lng", lng);
        mapData.put("name", name);
        mapData.put("icon", icon);
        mapData.put("vicinity", vicinity);
        mapData.put("price_level", price_level);
        mapData.put("rating", rating);
        return mapData;
    }

}
