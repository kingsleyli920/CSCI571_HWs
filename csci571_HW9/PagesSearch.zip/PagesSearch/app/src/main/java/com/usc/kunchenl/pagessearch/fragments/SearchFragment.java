package com.usc.kunchenl.pagessearch.fragments;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.places.GeoDataClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.android.gms.location.places.Places;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.LocationUtility;
import com.usc.kunchenl.pagessearch.Utilities.URLRequestUtility;
import com.usc.kunchenl.pagessearch.activities.SearchActivity;
import com.usc.kunchenl.pagessearch.myAdapter.MyAutocompleteAdapter;

import org.w3c.dom.Text;

import java.io.IOException;
import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class SearchFragment extends Fragment implements View.OnFocusChangeListener, View.OnClickListener {

    private EditText keyword;
    private Spinner category;
    private EditText distance;
    private RadioGroup radioGroup;
    private AutoCompleteTextView input_loc;
    private View view;
    private RadioButton current;
    private RadioButton other;
    private TextView warning_key;
    private TextView warning_loc;
    private TextView progress_bar_text;
    private ProgressBar progressBar;
    private ConstraintLayout progress_bar_layout;
    private Button searchBtn;
    private Button clearBtn;
    private ConstraintLayout constraintLayout;
    private Intent intent;
    private List<String> formData;
    private double lat;
    private double lng;
    private List<String> mDatas;
    private static final String GEOCODING_KEY = "AIzaSyClc3RMqH7MedLBTsgvtbwiXtqrl8RthDU";
    public static final String TAG = "AutoCompleteActivity";
    private static final int AUTO_COMP_REQ_CODE = 2;
    private AdapterView.OnItemClickListener onItemClickListener =
            new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    Toast.makeText(getContext(), "One item is clicked", Toast.LENGTH_LONG).show();
                }
            };
    protected GeoDataClient geoDataClient;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.fragment_search, container, false);
        initVariables();
        keyword.setOnFocusChangeListener(this);
        input_loc.setOnFocusChangeListener(this);

        // Detect radio buttons change
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // This will get the radiobutton that has changed in its check state
                RadioButton checkedRadioButton = (RadioButton) group.findViewById(checkedId);
                // This puts the value (true/false) into the variable
                boolean isChecked = checkedRadioButton.isChecked();
                // If the radiobutton that has changed in check state is now checked...
                if (isChecked) {
                    //Log.d(TAG, "onCheckedChanged: " + checkedRadioButton.getText());
                    switch (checkedId) {
                        case R.id.current_loc:
                            input_loc.setText("");
                            setReadOnly();
                            closeKeyboard();
                            break;
                        case R.id.other_loc:
                            setEditable();
                            break;
                        default:
                            Log.d(TAG, "onCheckedChanged: failed");
                    }
                }
            }
        });

        // Custom Autocomplete
        MyAutocompleteAdapter adapter = new MyAutocompleteAdapter(getContext());
        input_loc.setAdapter(adapter);
        input_loc.setOnItemClickListener(onItemClickListener);


        // Set click listener to search button
        searchBtn.setOnClickListener(this);

        // Set click listener to clear button
        clearBtn.setOnClickListener(this);

        return view;
    }

    // Init items
    private void initVariables() {
        keyword = (EditText) view.findViewById(R.id.keyword);
        category = (Spinner) view.findViewById(R.id.category);
        distance = (EditText) view.findViewById(R.id.distance);
        radioGroup = (RadioGroup) view.findViewById(R.id.radios);
        input_loc = (AutoCompleteTextView) view.findViewById(R.id.input_loc);
        current = (RadioButton) view.findViewById(R.id.current_loc);
        other = (RadioButton) view.findViewById(R.id.other_loc);
        warning_key = (TextView) view.findViewById(R.id.warning_key);
        warning_loc = (TextView) view.findViewById(R.id.warning_loc);
        progress_bar_text = (TextView) view.findViewById(R.id.progress_bar_text);
        warning_key.setVisibility(View.INVISIBLE);
        warning_loc.setVisibility(View.INVISIBLE);
        searchBtn = (Button) view.findViewById(R.id.search);
        clearBtn = (Button) view.findViewById(R.id.clear);
        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar);
        radioGroup.check(R.id.current_loc);
        progress_bar_layout = (ConstraintLayout) view.findViewById(R.id.progress_bar_include);
        constraintLayout = (ConstraintLayout) view.findViewById(R.id.main_constraintLayout);
        progress_bar_layout.setVisibility(View.INVISIBLE);

        setReadOnly();
    }

    // Close keyboard
    private void closeKeyboard() {
        //close keyboard
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(getContext().INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getActivity().getWindow().getDecorView().getWindowToken(), 0);
    }

    // Set input location text to readonly
    private void setReadOnly() {
        input_loc.setFocusable(false);
        input_loc.setFocusableInTouchMode(false);
        warning_loc.setVisibility(View.INVISIBLE);

    }

    // Set input location text view to editable
    private void setEditable() {
        input_loc.setFocusable(true);
        input_loc.setFocusableInTouchMode(true);
        //input_loc.requestFocus();
    }


    public void searchScreen() {
        Intent intent = new Intent();
        intent.setClass(getContext(), getClass());
        startActivity(intent);
    }

    // Detect focus change of edit text views
    @Override
    public void onFocusChange(View view, boolean hasFocus) {

        if (view == keyword) {
            if (!hasFocus) {
                closeKeyboard();
                String text = keyword.getText().toString().trim();
                if (text.length() <= 0) {
//                    Log.d(TAG, "onFocusChange: changed");
                    warning_key.setVisibility(View.VISIBLE);
                    keyword.setText("");
                    Toast.makeText(getContext(), "Please fill all fields!", Toast.LENGTH_SHORT).show();
                }
            } else {
                warning_key.setVisibility(View.INVISIBLE);
            }
        }

        if (view == input_loc) {
            if (!hasFocus) {
                closeKeyboard();
                String text = input_loc.getText().toString().trim();
                if (text.length() <= 0 && other.isChecked()) {
//                    Log.d(TAG, "onFocusChange: changed");
                    warning_loc.setVisibility(View.VISIBLE);
                    input_loc.setText("");
                    Toast.makeText(getContext(), "Please fill all fields!", Toast.LENGTH_SHORT).show();
                }
            } else {
                warning_loc.setVisibility(View.INVISIBLE);
            }
        }
    }

    @Override
    public void onClick(View v) {
        if (v == searchBtn) {
            String keyword_txt = keyword.getText().toString().trim();
            String loc_txt = input_loc.getText().toString().trim();
            if (keyword_txt.length() <= 0) {
                warning_key.setVisibility(View.VISIBLE);
                keyword.setText("");
                if (loc_txt.length() <= 0 && other.isChecked()) {
                    Log.d(TAG, "onClick: input_loc");
                    warning_loc.setVisibility(View.VISIBLE);
                    input_loc.setText("");
                    Toast.makeText(getContext(), "Please fill all fields!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(getContext(), "Please fill all fields!", Toast.LENGTH_SHORT).show();
                return;
            } else {
                if (loc_txt.length() <= 0 && other.isChecked()) {
                    Log.d(TAG, "onClick: input_loc");
                    warning_loc.setVisibility(View.VISIBLE);
                    input_loc.setText("");
                    Toast.makeText(getContext(), "Please fill all fields!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            formData = new ArrayList<String>();
            String keyword = this.keyword.getText().toString();
            String category = this.category.getSelectedItem().toString();
            String distance = this.distance.getText().toString();

            if (distance.isEmpty()) {
                //Log.d(TAG, "getData: distance no data");
                distance = "10";
            }
            formData.add(keyword);
            formData.add(category);
            formData.add(distance);
            // If current location is checked, use current location, otherwise use input location
            if (current.isChecked()) {
                Location location = LocationUtility.getInstance(getActivity()).showLocation();
                if (location != null) {
                    lat = location.getLatitude();
                    lng = location.getLongitude();
                    formData.add(String.valueOf(lat));
                    formData.add(String.valueOf(lng));

                    System.out.println(lat + ":" +  lng);
                    requestItems();
                }

            } else {
                String input_loc = this.input_loc.getText().toString();
                String urlWithParams = "https://maps.googleapis.com/maps/api/geocode/json?address=" + URLEncoder.encode(input_loc) + "&key=" + URLEncoder.encode(GEOCODING_KEY);
                URLRequestUtility urlRequestUtility = new URLRequestUtility();
                try {
                    urlRequestUtility.startConnection(urlWithParams, new URLRequestUtility.NetworkResponse() {
                        @Override
                        public void onSuccess(String body) {
                            final String jsonResponse = body;
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    JsonObject jsonObject = new ConvertToJsonObj(jsonResponse).convertToJson();
                                    JsonArray results = jsonObject.getAsJsonArray("results");
                                    String results_value = String.valueOf(results.get(0));
                                    JsonObject innerJson = new ConvertToJsonObj(results_value).convertToJson();
                                    JsonObject geometry = innerJson.getAsJsonObject("geometry");
                                    JsonObject location = geometry.get("location").getAsJsonObject();
                                    double lat = Double.parseDouble(String.valueOf(location.get("lat")));
                                    double lng = Double.parseDouble(String.valueOf(location.get("lng")));
                                    formData.add(String.valueOf(lat));
                                    formData.add(String.valueOf(lng));
//                                    for (String str : formData) {
//                                        System.out.println(str);
//                                    }
                                    requestItems();
                                }
                            });
                        }

                        @Override
                        public void onFailure() {
                            System.out.println("failed");
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        // Reset form
        if (v == clearBtn) {
            Log.d(TAG, "onClick: Clear Button");
            clearAll();
        }
    }

    private void requestItems() {
        String keyword = formData.get(0);
        String category = formData.get(1);
        String distance = String.valueOf((Integer.parseInt(formData.get(2)) * 1600));
        String lat = formData.get(3);
        String lng = formData.get(4);

        // Display progress bar
        progress_bar_text.setText("Fetching Result");
        progress_bar_layout.setVisibility(View.VISIBLE);
        searchBtn.setVisibility(View.INVISIBLE);
        clearBtn.setVisibility(View.INVISIBLE);
        final String urlWithParams =
                "http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/nearby/places?location=" +
                       URLEncoder.encode(lat) + "," + URLEncoder.encode(lng)
                        + "&radius=" + URLEncoder.encode(distance) + "&type=" +
                        URLEncoder.encode(category) + "&keyword=" + URLEncoder.encode(keyword);
        URLRequestUtility urlRequestUtility = new URLRequestUtility();
        try {
            urlRequestUtility.startConnection(urlWithParams
                    , new URLRequestUtility.NetworkResponse() {
                        @Override
                        public void onSuccess(String body) {
                            final String jsonResponse = body;
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    // Create an intent from this activity to search results page activity and open search results page
                                    intent = new Intent(getActivity(), SearchActivity.class);
                                    intent.putExtra("search_results", String.valueOf(jsonResponse));
                                    intent.putExtra("search_url", urlWithParams);
                                    getActivity().startActivity(intent);

                                }
                            });
                        }

                        @Override
                        public void onFailure() {
                            System.out.println("failed");
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        progress_bar_layout.setVisibility(View.INVISIBLE);
        searchBtn.setVisibility(View.VISIBLE);
        clearBtn.setVisibility(View.VISIBLE);

    }

    private void clearAll() {
        keyword.setText("");
        category.setSelection(0, true);
        distance.setText("");
        current.setChecked(true);
        other.setChecked(false);
        input_loc.setText("");
        warning_key.setVisibility(View.INVISIBLE);
        warning_loc.setVisibility(View.INVISIBLE);
    }

}
