package com.usc.kunchenl.pagessearch.myAdapter;

import android.app.Fragment;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.places.GeoDataClient;
import com.google.android.gms.location.places.PlacePhotoMetadata;
import com.google.android.gms.location.places.PlacePhotoResponse;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ExecuteNearbyResponse;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.SaveToLocalStorageUtility;
import com.usc.kunchenl.pagessearch.fragments.FavoriteFragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class MyPhotosAdapter extends RecyclerView.Adapter<MyPhotosAdapter.MyViewHolder> {

    private AppCompatActivity activity;
    private ImageView place_photo;
    private GeoDataClient mGeoDataClient;
    private List<PlacePhotoMetadata> photoList;
    private ArrayList<Bitmap> bitmapList;

    public MyPhotosAdapter(List<PlacePhotoMetadata> photoList, GeoDataClient mGeoDataClient) {
        this.photoList = photoList;
        this.mGeoDataClient = mGeoDataClient;
    }
    public MyPhotosAdapter(ArrayList<Bitmap> bitmapList) {
        this.bitmapList = bitmapList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        this.activity = (AppCompatActivity) parent.getContext();
        View view = LayoutInflater.from(activity).inflate(R.layout.photos_container, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

        Bitmap bitmap = bitmapList.get(position);
        Glide.with(activity).load(bitmap).into(place_photo);

    }

    @Override
    public int getItemCount() {
        return bitmapList.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {


        public MyViewHolder(View view) {

            super(view);
            place_photo = view.findViewById(R.id.place_photo);
        }

    }


}