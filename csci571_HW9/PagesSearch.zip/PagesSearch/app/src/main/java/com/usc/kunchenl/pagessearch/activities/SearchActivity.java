package com.usc.kunchenl.pagessearch.activities;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mopub.common.util.Json;
import com.usc.kunchenl.pagessearch.R;
import com.usc.kunchenl.pagessearch.Utilities.ConvertToJsonObj;
import com.usc.kunchenl.pagessearch.Utilities.NearbyResultItemUtility;
import com.usc.kunchenl.pagessearch.Utilities.SaveToLocalStorageUtility;
import com.usc.kunchenl.pagessearch.Utilities.URLRequestUtility;
import com.usc.kunchenl.pagessearch.interfaces.OnItemClickListener;
import com.usc.kunchenl.pagessearch.myAdapter.MyResultsAdapter;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar mToolbar;
    private String PAGE_TOKEN = "";
    private RecyclerView mRecyclerView;
    private String mData;
    private JsonArray mDatas;
    private MyResultsAdapter mAdapter;
    private int pageIndex = 0;
    private Button previous_btn;
    private Button next_btn;
    private List<String> localData;
    private SaveToLocalStorageUtility saveToLocalStorageUtility;
    private NearbyResultItemUtility nearbyResultItemUtility;
    private static final String GET_DETAILS_URL = "http://kunchenl-csci571-hw8.us-east-2.elasticbeanstalk.com/get/place/details?place_id=";
    private String search_url;
    private List<JsonArray> dataList;
    private List<String> page_tokens;
    private List<JsonArray> tempDataList;
    private boolean fetchAllPages = false;

    private ProgressBar progressBar;
    private ConstraintLayout progress_bar_layout;
    private TextView progress_bar_text;
    private int pageTotal;
    private int locationTag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataList = new ArrayList<JsonArray>();
        page_tokens = new ArrayList<String>();
        tempDataList = new ArrayList<JsonArray>();
        mDatas = getData();
        dataList.add(mDatas);
        if (mDatas.size() > 0) {
            setContentView(R.layout.search_results);
            setmToolbar();
            previous_btn = findViewById(R.id.previous_btn);
            progressBar = (ProgressBar) findViewById(R.id.progress_bar);
            progress_bar_layout = (ConstraintLayout) findViewById(R.id.progress_bar_results);
            progress_bar_text = (TextView) findViewById(R.id.progress_bar_text);
            progress_bar_layout.setVisibility(View.INVISIBLE);
            next_btn = findViewById(R.id.next_btn);
            previous_btn.setOnClickListener(this);
            next_btn.setOnClickListener(this);
            previous_btn.setEnabled(false);
            saveToLocalStorageUtility = new SaveToLocalStorageUtility(this);
            checkLocalStorage();
            setRecyclerView(mDatas);
            locationTag = 1;

        } else {
            setContentView(R.layout.no_results);
            setmToolbar();
            locationTag = 0;
        }

//        if (PAGE_TOKEN == null || PAGE_TOKEN == "") {
//            next_btn.setEnabled(false);
//        }
    }

    // Extract Data from coming String data and set corresponding value to nearbyResultItemUtility instance
    protected JsonArray getData() {
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            mData = bundle.getString("search_results");
            search_url = bundle.getString("search_url");
            JsonObject mDataJson = new ConvertToJsonObj(mData).convertToJson();

            // If there is next page token, get it from Json
            if (mDataJson.has("next_page_token")) {
                PAGE_TOKEN = String.valueOf(mDataJson.get("next_page_token"));
                page_tokens.add(PAGE_TOKEN);
            }

            JsonArray mDataArr = mDataJson.getAsJsonArray("results");
            return mDataArr;
        }
        return null;
    }

    // Set recyclerView
    private void setRecyclerView(JsonArray mDatas) {
        mRecyclerView = (RecyclerView) findViewById(R.id.id_recyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter = new MyResultsAdapter(mDatas, localData));
    }

    private void setmToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        // add back arrow to toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void checkLocalStorage() {
        localData = new ArrayList<String>();
        Map<String, ?> map = saveToLocalStorageUtility.getAll();
        for (Map.Entry<String, ?> entry : map.entrySet()) {
            //System.out.println("key: " + entry.getKey() + " value: " + entry.getValue());
            localData.add(entry.getKey());
        }
    }


    @Override
    public void onClick(View v) {
        if (v == previous_btn) {
            next_btn.setEnabled(true);
            checkLocalStorage();
            pageIndex--;
            mAdapter = new MyResultsAdapter(tempDataList.get(pageIndex), localData);
            mRecyclerView.setAdapter(mAdapter);
            if (pageIndex == 0) {
                previous_btn.setEnabled(false);
                PAGE_TOKEN = page_tokens.get(0);
            }
        }

        if (v == next_btn) {
            if (PAGE_TOKEN == "" && pageIndex == 0) {
                Toast.makeText(this, "No more pages of places", Toast.LENGTH_SHORT).show();
            } else {
                tempDataList.clear();
                tempDataList.addAll(dataList);
                pageIndex++;
                if (pageIndex > 0) {
                    previous_btn.setEnabled(true);
                }
                if (pageIndex <= dataList.size() - 1) {

                    checkLocalStorage();
                    mAdapter = new MyResultsAdapter(dataList.get(pageIndex), localData);
                    mRecyclerView.setAdapter(mAdapter);
                    if (pageIndex == pageTotal) {
                        next_btn.setEnabled(false);
                    }
                } else if (PAGE_TOKEN != "" && !fetchAllPages) {
                    pageTotal++;
                    System.out.println("pageIndex: " + pageIndex + "pageTotal: " + pageTotal);
                    // Display progress bar
                    progress_bar_text.setText("Fetching Result");
                    progress_bar_layout.setVisibility(View.VISIBLE);
                    String url = search_url + "&pagetoken=" + URLEncoder.encode(PAGE_TOKEN.replace("\"", ""));
                    URLRequestUtility urlRequestUtility = new URLRequestUtility();
                    try {
                        urlRequestUtility.startConnection(url
                                , new URLRequestUtility.NetworkResponse() {
                                    @Override
                                    public void onSuccess(final String body) {
                                        final String jsonResponse = body;

                                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                                            public void run() {
                                                progress_bar_layout.setVisibility(View.INVISIBLE);
                                                JsonObject jsonObject = new ConvertToJsonObj(jsonResponse).convertToJson();

                                                final JsonArray jsonArray = jsonObject.getAsJsonArray("results");
                                                if (jsonObject.has("next_page_token")) {
                                                    PAGE_TOKEN = String.valueOf(jsonObject.get("next_page_token"));
                                                } else {
                                                    PAGE_TOKEN = "";
                                                    fetchAllPages = true;
                                                    next_btn.setEnabled(false);
                                                }
                                                dataList.add(jsonArray);
                                                checkLocalStorage();
                                                mAdapter = new MyResultsAdapter(dataList.get(pageIndex), localData);
                                                mRecyclerView.setAdapter(mAdapter);
                                            }
                                        });

                                    }

                                    @Override
                                    public void onFailure() {
                                        System.out.println("failed");
                                    }
                                });
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else{
                    Toast.makeText(this, "No more pages of places", Toast.LENGTH_SHORT).show();
                    pageIndex--;
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (locationTag == 1) {
            checkLocalStorage();
            setRecyclerView(mDatas);
        }
    }
}
