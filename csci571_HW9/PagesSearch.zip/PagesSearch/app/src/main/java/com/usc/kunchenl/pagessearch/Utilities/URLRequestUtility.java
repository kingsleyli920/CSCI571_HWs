package com.usc.kunchenl.pagessearch.Utilities;

import android.content.Intent;
import android.util.Log;

import com.usc.kunchenl.pagessearch.activities.SearchActivity;

import java.io.IOException;
import java.io.Serializable;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class URLRequestUtility {


    public interface NetworkResponse{
        void onSuccess(String body);
        void onFailure();
    }

    public void startConnection(String url, final NetworkResponse okHttpCallBack) throws IOException {
        OkHttpClient client=new OkHttpClient();
        Request request=new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
               okHttpCallBack.onFailure();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
                if (response.isSuccessful()){

                    okHttpCallBack.onSuccess(response.body().string());
                }
            }
        });
    }
}
