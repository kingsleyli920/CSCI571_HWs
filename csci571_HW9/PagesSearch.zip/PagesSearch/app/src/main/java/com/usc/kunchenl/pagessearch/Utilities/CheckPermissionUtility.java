package com.usc.kunchenl.pagessearch.Utilities;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import static android.content.ContentValues.TAG;


public class CheckPermissionUtility {
    //  CHECK FOR LOCATION PERMISSION
    public static boolean checkPermission(Activity activity, String permission){
        int result = ContextCompat.checkSelfPermission(activity, permission);

        if (result == PackageManager.PERMISSION_GRANTED){

            return true;

        } else {

            return false;

        }
    }

    //REQUEST FOR PERMISSION
    public static void requestPermission(Activity activity, final int code, String permission){
        Log.d("SDK Version", String.valueOf(Build.VERSION.SDK_INT));

        if (ActivityCompat.shouldShowRequestPermissionRationale(activity,permission)){
            Log.d("content", "requestPermission: show alert");

            Toast.makeText(activity,"GPS permission allows us to access location data. Please allow in App Settings for additional functionality.",Toast.LENGTH_LONG).show();

        } else {
            Log.d("content", "requestPermission: No show alert");
            ActivityCompat.requestPermissions(activity,new String[]{permission},code);
        }
    }

}
