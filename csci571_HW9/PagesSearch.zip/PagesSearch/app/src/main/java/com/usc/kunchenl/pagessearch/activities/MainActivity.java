package com.usc.kunchenl.pagessearch.activities;

import android.Manifest;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import android.widget.LinearLayout;
import android.widget.TextView;

import com.usc.kunchenl.pagessearch.Utilities.CheckPermissionUtility;
import com.usc.kunchenl.pagessearch.myAdapter.MyMainFragmentsAdapter;
import com.usc.kunchenl.pagessearch.R;

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ViewPager mViewPager;
    private TabLayout mTabLayout;

    private MyMainFragmentsAdapter myMainFragmentsAdapter;

    private TabLayout.Tab search;
    private TabLayout.Tab favorites;

    private Location currentBestLocation = null;
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        locationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);
        // If select current location, the application needs location permission of the device
        String permission_fine = Manifest.permission.ACCESS_FINE_LOCATION;
        String permission_coarse = Manifest.permission.ACCESS_COARSE_LOCATION;
        int code = 200;
        // Get fine location
        if (!CheckPermissionUtility.checkPermission(MainActivity.this, permission_fine)) {
            Log.d(TAG, "onClick: apply permission");
            CheckPermissionUtility.requestPermission(MainActivity.this, code, permission_fine);
        }

        // Get coarse location
        if (!CheckPermissionUtility.checkPermission(MainActivity.this, permission_coarse)) {
            Log.d(TAG, "onClick: apply permission");
            CheckPermissionUtility.requestPermission(MainActivity.this, code, permission_coarse);
        }
        // Set toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        initViews();

    }

    // Initialize views
    private void initViews() {

        mViewPager = (ViewPager) findViewById(R.id.container);
        myMainFragmentsAdapter = new MyMainFragmentsAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(myMainFragmentsAdapter);
        mTabLayout = (TabLayout) findViewById(R.id.tabs);
        mTabLayout.setupWithViewPager(mViewPager);

        // Draw separator line between tabs
        View root = mTabLayout.getChildAt(0);
        if (root instanceof LinearLayout) {
            ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(getResources().getColor(R.color.separator));
            drawable.setSize(2, 1);
            ((LinearLayout) root).setDividerPadding(10);
            ((LinearLayout) root).setDividerDrawable(drawable);
        }

        TextView searchNewTab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        searchNewTab.setText(R.string.search);
        searchNewTab.setCompoundDrawablesWithIntrinsicBounds(R.drawable.search, 0, 0, 0);
        search = mTabLayout.getTabAt(0).setCustomView(searchNewTab);
        TextView favoritesNewTab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        favoritesNewTab.setCompoundDrawablesWithIntrinsicBounds(R.drawable.heart_outline_white, 0, 0, 0);
        favoritesNewTab.setText(R.string.favorites);
        favorites = mTabLayout.getTabAt(1).setCustomView(favoritesNewTab);

    }

    @Override
    public void onClick(View v) {

    }
}
